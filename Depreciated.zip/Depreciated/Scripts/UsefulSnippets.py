#oppexp = pd.read_csv('/home/jscharf/Research/polisciresearch/oppexp.csv', encoding = 'ISO-8859-1')

#purpCodes = pd.read_csv('/home/jscharf/Research/polisciresearch/purposecodes.csv', encoding = 'ISO-8859-1')

#setOf2010 = pd.read_csv('/home/jscharf/Research/polisciresearch/oppexpSetOf2010.csv', encoding = 'ISO-8859-1')
#setOf2012 = pd.read_csv('/home/jscharf/Research/polisciresearch/oppexpSetOf2012.csv', encoding = 'ISO-8859-1')
#setOf2014 = pd.read_csv('/home/jscharf/Research/polisciresearch/oppexpSetOf2014.csv', encoding = 'ISO-8859-1')
#setOf2016 = pd.read_csv('/home/jscharf/Research/polisciresearch/oppexpSetOf2016.csv', encoding = 'ISO-8859-1')

#Categories: media, digital, polling, legal, field, consulting, administrative


#how to get a word suggestion from datamuse
    #example: api.words(ml='final examination')
    #Returns words similar to this phrase as a list