Organization of the files:

	- Featur_Extractor.py

		Extracts useful features from one line of text. Should be built to work with
		multiple types of machine learning algorithms.

	- DecisionTree.py

		The planned first machine learning implementation.w
    
    - WordGenerator.py

        Used to generate lists of words, pos tags and morpheme generator
